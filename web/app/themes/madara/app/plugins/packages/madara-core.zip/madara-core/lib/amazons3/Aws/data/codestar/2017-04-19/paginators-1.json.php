<?php
// This file was auto-generated from sdk-root/src/data/codestar/2017-04-19/paginators-1.json
return [ 'pagination' => [],];
