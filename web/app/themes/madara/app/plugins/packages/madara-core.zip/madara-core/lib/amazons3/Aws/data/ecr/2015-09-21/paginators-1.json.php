<?php
// This file was auto-generated from sdk-root/src/data/ecr/2015-09-21/paginators-1.json
return [ 'pagination' => [ 'ListImages' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'imageIds', ], 'DescribeImages' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'imageDetails', ], 'DescribeRepositories' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'repositories', ], ],];
