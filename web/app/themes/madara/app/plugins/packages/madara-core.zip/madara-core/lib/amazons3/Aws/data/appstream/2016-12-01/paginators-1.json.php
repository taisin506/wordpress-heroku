<?php
// This file was auto-generated from sdk-root/src/data/appstream/2016-12-01/paginators-1.json
return [ 'pagination' => [],];
