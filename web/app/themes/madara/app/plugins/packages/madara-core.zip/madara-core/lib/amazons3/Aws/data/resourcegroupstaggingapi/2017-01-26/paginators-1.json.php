<?php
// This file was auto-generated from sdk-root/src/data/resourcegroupstaggingapi/2017-01-26/paginators-1.json
return [ 'pagination' => [],];
