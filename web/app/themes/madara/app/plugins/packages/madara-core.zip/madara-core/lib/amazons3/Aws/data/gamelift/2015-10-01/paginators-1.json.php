<?php
// This file was auto-generated from sdk-root/src/data/gamelift/2015-10-01/paginators-1.json
return [ 'pagination' => [],];
