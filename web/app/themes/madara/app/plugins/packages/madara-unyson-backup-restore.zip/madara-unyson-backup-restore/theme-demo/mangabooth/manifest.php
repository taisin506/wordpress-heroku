<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'Madara - Demo', 'madara' );
$manifest['screenshot'] = 'http://demo.mangabooth.com/wp-content/screenshot.png';
$manifest['preview_link'] = 'http://demo.mangabooth.com';
$manifest['demo_link'] = 'http://demo.mangabooth.com/wp-content/mangabooth-demo.zip';